<?php
/**
 * Created by PhpStorm.
 * User: flaviocassini
 * Date: 11/28/16
 * Time: 10:17 AM
 */
?>


<div class="container-fluid text-center">
    <div class="row content">
        <div class="col-sm-2 sidenav">
            <div class="well">
                <p>User Picture <br/><br/><br/><br/><br/><br/><br/><br/><br/></p>
            </div>
            <div class="well">
                <p>User Info <br/><br/><br/><br/><br/><br/><br/><br/><br/></p>
            </div>
        </div>
        <div class="col-sm-8 text-left">
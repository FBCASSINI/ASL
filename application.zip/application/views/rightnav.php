<?php
/**
 * Created by PhpStorm.
 * User: flaviocassini
 * Date: 11/28/16
 * Time: 10:21 AM
 */
?>

<hr>
            <h3>More User Info</h3>
            <p>Lorem ipsum...</p>
        </div>
        <div class="col-sm-2 sidenav">
            <div class="well">
                <p>Job Offers <br/><br/><br/><br/><br/><br/><br/><br/><br/></p>
            </div>
            <div class="well">
                <p>Job Offers <br/><br/><br/><br/><br/><br/><br/><br/><br/></p>
            </div>
        </div>
    </div>
</div>
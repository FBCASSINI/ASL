<?php
/**
 * Created by PhpStorm.
 * User: flaviocassini
 * Date: 11/24/16
 * Time: 7:47 AM
 */

function asset_url(){
    return base_url().'assets/';
}